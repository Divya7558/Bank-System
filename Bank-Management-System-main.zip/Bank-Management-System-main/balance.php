<?php
// Simulate retrieving the bank balance from a database or other source
$balance = 10000; // Replace with your actual balance retrieval logic

echo '<p>$' . number_format($balance, 2) . '</p>';
?>