
<!DOCTYPE html>  
<html>  
<head>  
<meta name="viewport" content="width=device-width, initial-scale=1">  
<style>  
body{  
  width: 100%;
  height: 100vh;
  background-image: linear-gradient(rgba(0,0,10,0.8),rgba(0,0,10,0.8)),url(image1.jpg);
  background-position:center;
  background-size: cover;
  position: relative; 
}  
.container {  
    padding: 80px;
    color: #FFF;  
}  
  
input[type=text], input[type=password], textarea {  
  width: 100%;  
  padding: 15px;  
  margin: 5px 0 22px 0;  
  display: inline-block;  
  border: none;  
  background: #f1f1f1;  
}  
input[type=text]:focus, input[type=password]:focus {   
  outline: none;  
}  
 div {  
            padding: 10px 0;  
         }  
hr {  
  border: 1px solid #f1f1f1;  
  margin-bottom: 25px;  
}  
.registerbtn {  
  background-color: black;  
  color: white; 
  border-radius: 40px; 
  padding: 16px 20px;  
  margin: 8px 0;  
  border: none;  
  cursor: pointer;  
  width: 100%;  
  opacity: 0.9;  
}  
.registerbtn:hover {  
  opacity: 1;  
}  
</style>  
</head>  
<body> 
<form>  
  <div class="container">  
  <center>  <h1>Registration</h1> </center>  
  <hr>  
  <label> Firstname </label>   
<input type="text" name="name" placeholder= "Firstname" />   
<label> Middlename: </label>   
<input type="text" name="middlename" placeholder="Middlename" />   
<label> Lastname: </label>    
<input type="text" name="lastname" placeholder="Lastname"  /> 
<label> Email</label>    
<input type="text" name="email" placeholder="Email"  />   
<label>   
Phone :  
</label>  
<input type="text" name="Phone" placeholder="Phone Number"  />    
<div>  
<label>   
Select User Type  
</label>     
<select>  
<option value="Course">Student</option>  
<option value="BCA">Employee</option>  
<option value="BBA">Senior Citizen</option>   
</select>  
<label>   
Select AccountType  
</label>     
<select>  
<option value="Course">Current Account</option>  
<option value="BCA">Saving Account</option>  
<option value="BBA">Other</option>   
</select>  
</div>
<div class="app-form-group">
              <input class="app-form-control" placeholder="INITIAL BALANCE" type="number" name="balance" required>
            </div>  
<div>  
<label>   
Gender :  
</label><br>  
<input type="radio" value="Male" name="gender" checked > Male   
<input type="radio" value="Female" name="gender"> Female   
<input type="radio" value="Other" name="gender"> Other   
</div>   
Current Address :  
<textarea cols="80" rows="5" placeholder="Current Address" value="address" name="Address">   
</textarea> 
Permanent Address :  
<textarea cols="80" rows="5" placeholder="Current Address" value="address" name="Address" >  
</textarea> 
<label>   
Gengerate MPIN:  
</label>  
<input type="text" name="pin" placeholder="Code"  />  
<button type="submit" class="registerbtn">Register</button>    
</form>  
</body>  
</html>  

