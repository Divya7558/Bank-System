<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="login.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <title>Create User</title>
</head>
<body>
    <nav>
     <label class="name"> PDK Bank</label>
       <ul>
        <li><a href="index.html">Home</a></li>
        <li><a href="Create_User.html">Create User</a></li>
       
      
       
       </ul>
    </nav>


     <div class="container">
         <div class="formbox">
            <h1> Login Here </h1>
            <form>
                 <div class="input-group">
                   
                   
                    <div class="input-field">
                      <i class="fa-solid fa-envelope"></i>
                       <input type="email" placeholder="Email Id">
                    </div>
                    <div class="input-field">
                       <i class="fa-solid fa-lock"></i>
                       <input type="Password" placeholder="Password">
                    </div>
                                 
             </div>
               <div class="btn-field">
                <button type="button"><a href="Screen.html">Login </button>
               </div>
            </form>
         </div>
         
     </div>
    

    
</body>
</html>