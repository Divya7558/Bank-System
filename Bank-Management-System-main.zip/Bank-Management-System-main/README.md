# Bank-Management-System

We are develpoed a bank management system for user and bank.It is easy to handle.Our bank provides you many features with the simple interface .You can easily handle all the options of the banking.You can easily transfer the money to others, can easily receive money ,transition history at one click ,you can get load as per your need and many more features like this.We give a garrenty that we provides you a safe and secure banking. We provide many more features than the other banks.
